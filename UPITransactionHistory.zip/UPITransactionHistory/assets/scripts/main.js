init();

function init() {
    const userId = 1;
    const recipientId = 2;
    const getTransactionHistoryURL = `https://dev.onebanc.ai/assignment.asmx/GetTransactionHistory?` +
        `userId=${userId}` +
        `&recipientId=${recipientId}`;

    this.templateNode = document.getElementById('chat-bubble-template');

    fetchTransactionHistory(getTransactionHistoryURL);

    processTransactionHistoryResponse();

}

// functions declarations
function processTransactionHistoryResponse() {
    const transactions = JSON.parse(this.responseText).transactions;

    transactions.forEach(item => {
        var bubbleNode = returnBubbleNode(item);
        document.getElementById('transactionsContainer').appendChild(bubbleNode);
    });

    templateNode.remove();

}

function returnBubbleNode(transactionObj) {
    var newNode = templateNode.cloneNode(true);
    var otherDetails = newNode.getElementsByClassName('otherDetails')[0].cloneNode(true);
    var nodeDirection = 1; // default
    const nodeType = transactionObj.type;
    var actionStatus = transactionObj.status;
    var actionMsgClass = '';
    var actionMsgString = '';
    newNode.getElementsByClassName('otherDetails')[0].remove();
    newNode.setAttribute('data-timestamp', getFormattedDate(new Date(transactionObj.startDate)));

    //set direction
    if (transactionObj.direction === 1) {
        newNode.classList.add("right-bubble");
        nodeDirection = 1
    }
    else {
        newNode.classList.add("left-bubble");
        nodeDirection = 2
    }

    actionMsgClass = getActionMsgClass(transactionObj.status);
    actionMsgString = getActionMsg(nodeDirection, nodeType, actionStatus);

    // set amount
    newNode.getElementsByClassName('amount')[0].textContent = transactionObj.amount;

    // create transaction ID node
    var newOtherDetails = otherDetails.cloneNode(true);
    newOtherDetails.getElementsByClassName('label')[0].textContent = 'Transaction Id';
    newOtherDetails.getElementsByClassName('info')[0].textContent = transactionObj.id;

    // add transaction ID
    newNode.getElementsByClassName('left')[0].appendChild(newOtherDetails);

    // create message node
    if (transactionObj.description && transactionObj.description !== '') {
        newOtherDetails = otherDetails.cloneNode(true);
        newOtherDetails.getElementsByClassName('label')[0].textContent = 'Remarks';
        newOtherDetails.getElementsByClassName('info')[0].textContent = transactionObj.description;

        // add message node
        newNode.getElementsByClassName('left')[0].appendChild(newOtherDetails);
    }

    // create and set Action node
    const actionMsgNode = newNode.getElementsByClassName('actionMsg')[0]
    newNode.getElementsByClassName('actionMsg')[0].remove();
    actionMsgNode.textContent = actionMsgString;
    actionMsgNode.classList.value = '';
    actionMsgNode.classList.add('actionMsg');
    actionMsgNode.classList.add(actionMsgClass);

    const seeMoreBtn = newNode.getElementsByClassName('moreButton')[0];
    newNode.getElementsByClassName('right')[0].insertBefore(actionMsgNode, seeMoreBtn);

    const actionBtnConfig = getActionBtnStatus(nodeDirection, nodeType);
    if (!actionBtnConfig.show) {
        newNode.getElementsByClassName('actionButtonSection')[0].remove()
    }
    else {
        if (!actionBtnConfig.pay) {
            newNode.getElementsByClassName('payBtn')[0].remove()
        }
        if (!actionBtnConfig.decline) {
            newNode.getElementsByClassName('declineBtn')[0].remove()
        }
        if (!actionBtnConfig.cancel) {
            newNode.getElementsByClassName('cancelBtn')[0].remove()
        }
    }

    newNode.removeAttribute('id');
    return newNode;
}

function fetchTransactionHistory(url) {
    var oReq = new XMLHttpRequest();
    oReq.addEventListener("load", processTransactionHistoryResponse);
    oReq.open("GET", url);
    oReq.send();
}

function getActionMsg(dir, action, status) {
    const DAS = '' + dir + action + status;
    const actionMsgs = {

        // outgoing + pay + status
        '111': 'Payment pending',
        '112': 'You paid',
        '113': 'Payment expired',
        '114': 'Payment rejected',
        '115': 'Cancelled',

        // outgoing + collect + status
        '121': 'You requested',
        '122': 'You recieved',
        '123': 'Request expired',
        '124': 'Request rejected',
        '125': 'Cancelled',

        // incoming + pay + status
        '211': 'Payment pending',
        '212': 'You recieved',
        '213': 'Request expired',
        '214': 'Request rejected',
        '215': 'Cancelled',

        // incoming + collect + status
        '221': 'Request recieved',
        '222': 'You Paid',
        '223': 'Request expired',
        '224': 'Request rejected',
        '225': 'Cancelled'
    };
    return actionMsgs[DAS];
}

function getActionMsgClass(status) {
    const statusStr = '' + status;
    const classList = {
        '1': 'actionDue',
        '2': 'actionDone',
        '3': 'actionExpired',
        '4': 'actionRejected',
        '5': 'actionCancelled'
    };
    return classList[statusStr];
}

function getActionBtnStatus(dir, action) {
    const actionTypeStr = '' + dir + action;
    actionBtnConfig = {
        show: false,
        pay: false,
        decline: false,
        cancel: false
    }
    if (actionTypeStr === '22') {
        actionBtnConfig = {
            show: true,
            pay: true,
            decline: true,
            cancel: false
        }

    }
    else if (actionTypeStr === '12') {
        actionBtnConfig = {
            show: true,
            pay: false,
            decline: false,
            cancel: true
        }
    }
    return actionBtnConfig;
}

function getFormattedDate(dateObj) {
    const dateStrArr = dateObj.toDateString().split(' ');
    return `${dateStrArr[2]}-${dateStrArr[1]}-${dateStrArr[3]}`;
}
